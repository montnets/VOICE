package main

import "fmt"
import "flag"
import "strconv"
import "strings"
import "os"
import "log"
import "montnets/mwgate/voiceutil"

// 模板发送
func templateSend(userid string, pwd string, mobile string, tmplid string, msgtype string, content string) {

	fmt.Println("templateSend demo begin")

	// 将数据打包
	sendobj := voiceutil.NewTemplateSend(userid, pwd, mobile, content, msgtype, tmplid)
	// 发送数据
	voiceutil.SendAndRecvOnce(sendobj)
}

func getRpt(userid string, pwd string, retsize int) {
	fmt.Println("getRpt demo begin")
	if false == voiceutil.ValidateUserId(userid) {
		return
	}

	if false == voiceutil.ValidatePwd(pwd) {
		return
	}

	// 将数据打包
	sendobj := voiceutil.NewGetRpt(userid, pwd, retsize)
	// 发送数据
	voiceutil.SendAndRecvOnce(sendobj)
}

// 查询余额
func getBalance(userid string, pwd string) {
	fmt.Println("getBalance demo begin")

	if false == voiceutil.ValidateUserId(userid) {
		return
	}

	if false == voiceutil.ValidatePwd(pwd) {
		return
	}

	// 将数据打包
	sendobj := voiceutil.NewGetBalance(userid, pwd)
	// 发送数据
	voiceutil.SendAndRecvOnce(sendobj)
}

// 查询剩余金额或条数
func getRemains(userid string, pwd string) {
	fmt.Println("getRemains demo begin")

	if false == voiceutil.ValidateUserId(userid) {
		return
	}

	if false == voiceutil.ValidatePwd(pwd) {
		return
	}

	// 将数据打包
	sendobj := voiceutil.NewGetBalance(userid, pwd)
	// 发送数据
	voiceutil.SendAndRecvOnce(sendobj)
}
func main() {

	// 用户账号：长度最大6个字符，统一大写,如提交参数中包含apikey，
	// 则可以不用填写该参数及pwd，两种鉴权方式中只能选择一种方式来
	//userid := "kuku6"
	userid := flag.String("u", "kuku6", "用户账号：长度最大6个字符，统一大写")

	// 用户密码：定长小写32位字符, 如提交参数中包含apikey，则可以
	// 不用填写该参数及userid，两种鉴权方式中只能选择一种方式来进
	// 行鉴权。
	// pwd := "123456"
	pwd := flag.String("p", "123456", "用户密码：定长小写32位字符")

	cmd := flag.String("c", "", "测试类型， template_send, get_rpt, get_balance, get_remains")

	mainAddr := flag.String("mAddr", "api01.monyun.cn:7901", "主服务器地址<域名:端口>")
	bakAddr := flag.String("bAddr", "api01.monyun.cn:7901;api01.monyun.cn:7901;api01.monyun.cn:7901", "备用服务器地址<域名:端口;域名:端口> 最多支持三个")

	logName := flag.String("l", "./access.log", "输出日志文件名，默认为：./access.log")

	flag.Parse()

	address1 := ""
	address2 := ""
	address3 := ""

	bAddrs := strings.Split(*bakAddr, ";")
	for i, v := range bAddrs {
		switch {
		case 0 == i:
			address1 = v
		case 1 == i:
			address2 = v
		case 2 == i:
			address3 = v
		default:
		}
	}

	cm := voiceutil.GetConfigManager()
	cm.RequestPath = "/voice/v2/std/"
	ret := cm.SetIpInfo(*mainAddr, address1, address2, address3)
	if 0 != ret {
		fmt.Println("ConfigManager.SetIpInfo failed, ", string(voiceutil.PkgToJson(cm)[:]), ret)
	}

	file, err := os.OpenFile(*logName, os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		log.Fatalln("fail to create ", *logName, "file!")
	}
	voiceutil.Logger = log.New(file, "", log.LstdFlags)
	params := flag.Args()

	switch {
	case "template_send" == *cmd: // 单条发送
		if len(params) != 4 {
			fmt.Println("参数错误，格式为：<mobile><tmplid><msgtype><content>")
		}
		templateSend(*userid, *pwd, params[0], params[1], params[2], params[3])
	case "get_rpt" == *cmd: // 获取rpt
		if len(params) > 1 {
			fmt.Println("参数错误，格式为：<resize>")
		}
		resize := 200
		if nil != params {
			re, err := strconv.Atoi(params[0])
			if nil != err {
				resize = 200
			}
			resize = re
		}
		getRpt(*userid, *pwd, resize)
	case "get_balance" == *cmd: // 查询余额
		getBalance(*userid, *pwd)
	case "get_remains" == *cmd: // 查询剩余金额或条数
		getRemains(*userid, *pwd)
	default:
		fmt.Println("未能识别的命令")
	}

	// // 用户账号：长度最大6个字符，统一大写,如提交参数中包含apikey，
	// // 则可以不用填写该参数及pwd，两种鉴权方式中只能选择一种方式来
	// userid := "kuku6"

	// // 用户密码：定长小写32位字符, 如提交参数中包含apikey，则可以
	// // 不用填写该参数及userid，两种鉴权方式中只能选择一种方式来进
	// // 行鉴权。
	// pwd := "123456"

	// mobile := "158xxxxxxxx"

	// //主IP信息  必填
	// masterIpAddress := "api01.monyun.cn:7901"

	// //备IP1  选填
	// ipAddress1 := ""

	// //备IP2  选填
	// ipAddress2 := ""

	// //备IP3  选填
	// ipAddress3 := ""

	// cm := smsutil.GetConfigManager()

	// cm.RequestPath = "/voice/v2/std/"

	// ret := cm.SetIpInfo(masterIpAddress, ipAddress1, ipAddress2, ipAddress3)
	// if 0 != ret {
	// 	fmt.Println("ConfigManager.SetIpInfo failed, ", string(smsutil.PkgToJson(cm)[:]), ret)
	// }

	// // 模板发送
	// templateSend(userid, pwd, mobile)

	// // 查询剩余金额或条数
	// getRemains(userid, pwd)

	// // 查询余额
	// getBalance(userid, pwd)

	// //运行获取上行状态报告协程
	// getRpt(userid, pwd, 200)
	// //清除所有IP (此处为清除IP示例代码，如果需要修改IP，请先清除IP，再设置IP)
	cm.RemoveAllIpInfo()
}
