package voiceutil

import "time"
import "net/url"
import "strings"
import "crypto/md5"
import "encoding/hex"
import "encoding/json"
import "net/http"
import "fmt"
import "io/ioutil"
import "github.com/axgle/mahonia"
import "log"

var serial_number uint = 1

var Logger *log.Logger

func FormatCurrentTime() string {
	now := time.Now()
	return now.Format("060102150405")[2:]
}

func FormatContent(content string) string {
	// 去掉两端的空格
	content = strings.TrimSpace(content)
	// 转为GBK
	gbk := mahonia.NewEncoder("gbk").ConvertString(content)
	v := url.Values{}
	v.Set("aa", gbk)
	str := v.Encode()
	arr := strings.Split(str, "=")
	return arr[1]
}

func GetExno() string {
	return "1234"
}

func GetCustid() (custid string) {
	now := time.Now()
	serialno := fmt.Sprintf("%06d", serial_number)
	serial_number += 1
	num := now.Format("060102150405")
	custid = "20" + num + serialno
	return custid
}

func GetExdata() (exdata string) {
	now := time.Now()
	num := now.Format("060102150405")
	exdata = "20" + num
	return exdata
}

func GetSvrtype() string {
	return "SM0001"
}

func CryptPwd(userid string, pwd string, strtime string) string {
	// 密码加密模式：账号：J10003, 密码：111111, 固定字符串：00000000
	// 时间戳：0803192020
	// MD5加密之前的对应字符串：J10003000000001111110803192020
	// MD5加密之后的密码字符串：26dad7f364507df18f3841cc9c4ff94d
	md5Ctx := md5.New()
	md5Ctx.Write([]byte(userid + "00000000" + pwd + strtime))
	encryptPwd := md5Ctx.Sum(nil)
	pwdmd5 := hex.EncodeToString(encryptPwd[:])
	return pwdmd5
}

func PkgToJson(pkg interface{}) []byte {
	if nil == pkg {
		return nil
	}

	ret, err := json.Marshal(pkg)
	if err != nil {
		fmt.Println("error:", err)
		return nil
	}
	return ret
}

func HttpPostOnce(url string, data []byte, content_type string) (int, []byte, error) {

	body := strings.NewReader(string(data[:]))
	client := &http.Client{}
	reqest, _ := http.NewRequest("POST", url, body)
	reqest.Header.Set("Accept-Encoding", "gzip, deflate")
	reqest.Header.Set("Content-Type", content_type)
	reqest.Header.Set("Connection", "Close")

	response, err := client.Do(reqest)
	if err != nil {
		return 0, nil, err
	}
	defer response.Body.Close()
	resbody, _ := ioutil.ReadAll(response.Body)
	//bodystr := string(body)
	return response.StatusCode, resbody, err
}

func RemoveAddressElement(s []string, element string) []string {
	ret := make([]string, 0)
	for _, v := range s {
		if v != element {
			ret = append(ret, v)
		}
	}
	return ret
}

type PostObj interface {
	GetUserid() string
	GetPwd() string
	GetTimestemp() string
	GetName() string
	ParseRecvData([]byte) bool
}

func SendAndRecvOnce(postobj PostObj) bool {

	fmt.Println("SendAndRecvOnce", postobj.GetName(), "begin")
	// 获取发送IP
	fmt.Println("SendAndRecvOnce", postobj.GetName(), ", get send address begin")
	checkaddr := &CheckAddress{Cm: GetConfigManager()}

	addr := checkaddr.GetAddressByUserID(postobj.GetUserid(), postobj.GetPwd(), postobj.GetTimestemp())
	if "" == addr {
		fmt.Println("SendAndRecvOnce", postobj.GetName(), "GetAddressByUserID failed.")
		Logger.Println("SendAndRecvOnce", postobj.GetName(), "GetAddressByUserID failed.")
		return false
	}
	fmt.Println("SendAndRecvOnce", postobj.GetName(), ", get send address is", addr)

	// 获取发送URL
	requestHost := "http://" + addr
	url := requestHost + checkaddr.Cm.RequestPath + postobj.GetName()

	fmt.Println("SendAndRecvOnce", postobj.GetName(), ", get send url is", url)

	// 组包
	data := PkgToJson(postobj)

	fmt.Println("SendAndRecvOnce", postobj.GetName(), ", body is", string(data[:]))

	rep_code, rep_body, err := HttpPostOnce(url, data, "application/json")
	if nil != err || 200 != rep_code {
		fmt.Println("SendAndRecvOnce", postobj.GetName(), "Post data failed, url:", url, "data:", string(data[:]), ", rep_code:", rep_code, ", body:", rep_body, ", err:", err)
		Logger.Println("SendAndRecvOnce", postobj.GetName(), "Post data failed, url:", url, "data:", string(data[:]), ", rep_code:", rep_code, ", body:", rep_body, ", err:", err)

		return false
	}
	Logger.Println(string(rep_body[:]))
	ret := postobj.ParseRecvData(rep_body)
	return ret
}
