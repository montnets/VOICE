package voiceutil

type VoiceData struct {

	//短信接收的手机号，用英文逗号(,)分隔，最大1000个号码。一次提交的号码类型不受限制，但手机会做验证，若有不合法的手机号将会被退回。号码段类型分为：移动、联通、电信手机
	// 注意：请不要使用中文的逗号
	Mobile string `json:"mobile"`

	//语音内容：编码方法：urlencode（GBK明文）消息类型为1 表示是验证码（4到8位字符 只能是数字或者字母不区分大小写）

	Content string `json:"content"`

	// 消息类型：
	// 1：语音验证码
	// 3：语音通知：只有当显号为12590时，实际发出的消息类型仍为语音验证码，并且使用梦网自带的语音模板发送语音验证码，其他显号下仍然使用语音模板编号对应的模板发送语音通知。
	Msgtype string `json:"msgtype"`

	// 语音模版编号：
	// 当msgtype为1时，语音模板编号为非必须项，如提交此字段则使用与提交模板编号对应的模板发送语音验证码，如不提交此字段或填空则使用梦网自带的语音模板发送语音验证码
	// 当msgtype为3时，语音模板编号为必填项
	Tmplid string `json:"tmplid"`

	// 扩展号
	// 回拨显示的号码：目前需要备案后才能支持使用，如果没有备案将会返回错误码 -401094（显示号码不合法）
	Exno string `json:"exno"`

	// 用户自定义流水号：该条语音在您业务系统内的ID，比如订单号或者语音发送记录的流水号。填写后发送状态返回值内将包含用户自定义流水号。最大可支持32位的ASCII字符
	Custid string `json:"custid"`
}

func NewVoiceData(mobile string, content string, msgtype string, tmplid string) (voidata *VoiceData) {
	voidata = &VoiceData{
		Mobile:  mobile,
		Content: FormatContent(content),
		Msgtype: msgtype,
		Tmplid:  tmplid,
		Custid:  GetCustid(),
		Exno:    ""}
	return voidata
}

type TemplateSend struct {
	*UserInfo
	*VoiceData
}

func NewTemplateSend(userid string, pwd string, mobile string, content string, msgtype string, tmplid string) *TemplateSend {
	return &TemplateSend{NewUserInfo(userid, pwd), NewVoiceData(mobile, content, msgtype, tmplid)}
}

func (s *TemplateSend) GetName() string {
	return "template_send"
}
