﻿#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# **********************************************************************
#
# Description: 测试云语音sdk接口
#
# Author: Peter Hu
#
# Created Date:2017/5/12
#
# Copyright (c) ShenZhen Montnets Technology, Inc. All rights reserved.
#
# **********************************************************************
import sys
from voiceclient import *

def menu():
    print("""
usage:
1: templateSend(voice message, the reciever is only ONE)
2: getVoiceRpt
3: getVoiceRemains
x: exit
?: help

IMPORTANT:
If you wish the other pepole are able to recieve call or text,
Please change mobile(s) into their phone number by editting 'voiceclient.py'
""")

class VoiceApiDemo():
    def run(self, args):
        # 短信实例
        voiceClient = VoiceClient()

        menu()
        c = None
        while c != 'x':
            try:
                sys.stdout.write("==> ")
                sys.stdout.flush()
                c = sys.stdin.readline().strip()
                if c == '1':
                    # 发送电话语音
                    voiceClient.voiceTemplateSend()
                elif c == '2':
                    # 获取状态报告
                    voiceClient.getVoiceRpt()
                elif c == '3':
                    # 查询剩余条数
                    voiceClient.getVoiceRemains()
                elif c == 'x':
                    pass # Nothing to do
                elif c == '?':
                    menu()
                else:
                    print("unknown command `" + c + "'")
                    menu()
            except EOFError:
                break
            except KeyboardInterrupt:
                break
        return

if __name__ == "__main__":
    app = VoiceApiDemo()
    sys.exit(app.run(sys.argv))