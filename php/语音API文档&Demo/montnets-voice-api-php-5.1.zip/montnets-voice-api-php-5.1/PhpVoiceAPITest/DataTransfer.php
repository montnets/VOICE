<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-03-06
 * Time: 21:40
 */
require_once('PhpVoiceAPIDemo_JSON/ConfigManager.php');
require_once('PhpVoiceAPIDemo_JSON/VoiceSendConn.php');
$Method=$_POST['Method'];//获取方法名

if(!empty($Method))//获取到请求方法名称
{
    $data_transfer=new data_transfer();
    switch($Method)
    {
        case 'get_ip':$result=$data_transfer->get_ip();
                        echo $result;
                        break;
        case 'set_ip':$result=$data_transfer->set_ip();
                        echo $result;
                        break;
        case 'template_send':$result=$data_transfer->tmplid_send(1);
                        echo $result;
                        break;
        case 'template_send_1':$result=$data_transfer->tmplid_send(3);
                        echo $result;
                        break;
        case 'get_balance':$result=$data_transfer->get_balance();
                        echo $result;
                        break;
        case 'get_rpt':$result=$data_transfer->get_rpt();
                        echo $result;
                        break;
        case 'remove_ip':$result=$data_transfer->remove_ip();
                            echo $result;
                            break;
    }
}
class data_transfer
{
    /*
     * 获取IP信息
     */
    public function get_ip()
    {
        try {
            $ConfigManager = new ConfigManager();
            if ($ip = $ConfigManager->get_ip())//获取IP成功
            {
                $result = json_encode($ip);
                return $result;//返回IP集合
            } else {
                return null;//返回null
            }
        }
        catch(Exception $e){
            return null;//返回null
        }
    }
    /*
     * 设置IP信息
     */
    public function set_ip()
    {
        $ConfigManager=new ConfigManager();
        //初始化数组
        $ip=array();
        //主IP
        if(!empty($_POST['ip1'])){
            $ip['ipAddress1'] = $_POST['ip1'];//获取IP信息
        }
        //备IP1
        if(!empty($_POST['ip2'])){
            $ip['ipAddress2'] = $_POST['ip2'];//获取IP信息
        }
        //备IP2
        if(!empty($_POST['ip3'])){
            $ip['ipAddress3'] = $_POST['ip3'];//获取IP信息
        }
        //备IP3
        if(!empty($_POST['ip4'])){
            $ip['ipAddress4'] = $_POST['ip4'];//获取IP信息
        }
        try {
            if(!empty($ip)) //获取到设置好的IP值
            {
                if ($ConfigManager->set_usableip($ip)) //保存设置的IP成功
                {
                    $result = json_encode(array('state' => 0, 'info' => "ip保存成功！"));
                    return $result;//以JSON格式返回数据
                } else {
                    $result = json_encode(array('state' => 1, 'info' => "ip保存失败！"));
                    return $result;//以JSON格式返回数据
                }
            }
            else//未获取到设置好的IP值
            {
                $result = json_encode(array('state' => 1, 'info' => "ip保存失败！"));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "ip保存失败！错误信息".$e->getMessage()));
            return $result;//以JSON格式返回数据
        }
    }
    /*
     * 清除IP信息
     */
    public function remove_ip()
    {
        try {
        $ConfigManager=new ConfigManager();
            if($ConfigManager->removeAllIpInfo())//获取IP成功
            {
                $result = json_encode(array('state' => 0, 'info' => "ip信息重置成功"));
                return $result;//以JSON格式返回数据
            }
            else
            {
                $result = json_encode(array('state' => 1, 'info' => "ip信息重置失败"));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "ip信息重置失败".$e->getMessage()));
            return $result;//以JSON格式返回数据
        }
    }
    /*
    * 单条信息发送
    */
    public function tmplid_send($msgtype)
    {
        $VoiceSendConn=new VoiceSendConn();
        //初始化数组
        $data=array();
        $message_type='语音通知';//发送类型文字描述
        //设置发送语音验证码内容
        if($msgtype===1)//语音验证码
        {
            if (!empty($_POST['content'])) {
                $data['content'] = $_POST['content'];//获取IP信息
            }
            $message_type = '语音验证码';
        }
        else {
            $data['content'] = '';//若无信息则返回null
        }
        //消息类型
        $data['msgtype'] = $msgtype;
        //设置账号(账号需要大写)
        if(!empty($_POST['userid'])){
            $data['userid'] = $_POST['userid'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['pwd'])){
            $data['pwd'] = $_POST['pwd'];//获取IP信息
        }
        // 设置手机号码 此处只能设置一个手机号码
        if(!empty($_POST['mobile'])){
            $data['mobile'] = $_POST['mobile'];//获取IP信息
        }
        // 语音模板编号
        if(!empty($_POST['tmplid'])){
            $data['tmplid'] = $_POST['tmplid'];//获取IP信息
        }
        // 设置回拨显示的号码
        if(!empty($_POST['exno'])){
            $data['exno'] = $_POST['exno'];//获取IP信息
        }
        //用户自定义流水编号
        if(!empty($_POST['custid'])){
            $data['custid'] = $_POST['custid'];//获取IP信息
        }
        //请求地址
        if(!empty($_POST['url'])){
            $url = $_POST['url'];//获取请求地址
        }
        //密码是否加密
        $isEncryptPwd = $_POST['isEncryptPwd'];
        if($isEncryptPwd==1)
        {
            $isEncryptPwd=true;
        }
        else
        {
            $isEncryptPwd=false;
        }
        try {
            $result = $VoiceSendConn->templateSend($url, $data, $isEncryptPwd);
            if ($result['result'] === 0) {
                $result['mobile']=$data['mobile'];//返回值赋值此次发送的电话号码
                $result = json_encode(array('state' => 0, 'info' => $message_type."发送成功！",'data'=>$result));
                return $result;//以JSON格式返回数据
            } else {
                $result = json_encode(array('state' => 1, 'info' => $message_type."发送失败！",'data'=>$result));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => $message_type."发送失败！错误信息".$e->getMessage(),'data'=>array('result'=>'')));
            return $result;
        }
    }

    /*
   * 查询余额
   */
    public function get_balance()
    {
        $VoiceSendConn=new VoiceSendConn();
        //初始化数组
        $data=array();
        //设置账号(账号需要大写)
        if(!empty($_POST['userid'])){
            $data['userid'] = $_POST['userid'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['pwd'])){
            $data['pwd'] = $_POST['pwd'];//获取IP信息
        }
        //请求地址
        if(!empty($_POST['url'])){
            $url = $_POST['url'];//获取请求地址
        }
        //密码是否加密
        $isEncryptPwd = $_POST['isEncryptPwd'];
        if($isEncryptPwd==1)
        {
            $isEncryptPwd=true;
        }
        else
        {
            $isEncryptPwd=false;
        }
        try {
            $result = $VoiceSendConn->getBalance($url, $data, $isEncryptPwd);
            if ($result['result'] === 0) {
                $result = json_encode(array('state' => 0, 'info' => "查询余额成功！",'data'=>$result));
                return $result;//以JSON格式返回数据
            } else {
                $result = json_encode(array('state' => 1, 'info' => "查询余额失败！",'data'=>$result));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "查询余额失败！错误信息".$e->getMessage(),'data'=>array('result'=>'')));
            return $result;
        }
    }

    /*
   * 获取状态报告
   */
    public function get_rpt()
    {
        $VoiceSendConn=new VoiceSendConn();
        //初始化数组
        $data=array();
        //设置账号(账号需要大写)
        if(!empty($_POST['userid'])){
            $data['userid'] = $_POST['userid'];//获取IP信息
        }
        //设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
        if(!empty($_POST['pwd'])){
            $data['pwd'] = $_POST['pwd'];//获取IP信息
        }
        //请求地址
        if(!empty($_POST['url'])){
            $url = $_POST['url'];//获取请求地址
        }
        //密码是否加密
        $isEncryptPwd = $_POST['isEncryptPwd'];
        if($isEncryptPwd==1)
        {
            $isEncryptPwd=true;
        }
        else
        {
            $isEncryptPwd=false;
        }
        $data['retsize']=10;//获取条数默认10条
        try {
            $result = $VoiceSendConn->getRpt($url, $data, $isEncryptPwd);
            if ($result['result'] === 0) {
                $result = json_encode(array('state' => 0, 'info' => "获取状态报告成功！",'data'=>$result));
                return $result;//以JSON格式返回数据
            } else {
                $result = json_encode(array('state' => 1, 'info' => "获取状态报告失败！",'data'=>$result));
                return $result;//以JSON格式返回数据
            }
        }catch (Exception $e) {
            $result = json_encode(array('state' => 1, 'info' => "获取状态报告失败！错误信息".$e->getMessage(),'data'=>array('result'=>'')));
            return $result;
        }
    }
}