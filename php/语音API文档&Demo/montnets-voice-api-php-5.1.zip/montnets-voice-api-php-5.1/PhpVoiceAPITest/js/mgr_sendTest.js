$(document).ready(function(){
	$.ajax({
		cache: true,
		type: "POST",
		url:'./DataTransfer.php',
		data:{"Method":'get_ip'},// ip表单
		dataType: "json",
		success: function(data) {
			if(data=='') //已经设置过IP信息
			{
				$('#first').show();//设置IP显示
				$('#second').hide();//业务请求隐藏
			}
			else
			{
				$('#first').hide();//设置IP隐藏
				$('#second').show();//业务请求显示
			}
		},
		error: function(e) {
			$('#first').show();//设置IP显示
			$('#second').hide();//业务请求隐藏
		}
	});
});

//语音接口接口类型选择之后的操作
$('.st_rType').on('change',function(){
	var options=$(".st_rType option:selected").val();
	if(options == 1){
		$('#template_send').show();
		$('#template_send_1').hide();
		$('#get_balance').hide();
		$('#get_rpt').hide();
	}else if(options == 2){
		$('#template_send').hide();
		$('#template_send_1').show();
		$('#get_balance').hide();
		$('#get_rpt').hide();
	}else if(options == 3){
		$('#template_send').hide();
		$('#template_send_1').hide();
		$('#get_balance').show();
		$('#get_rpt').hide();
	}else if(options == 4){
		$('#template_send').hide();
		$('#template_send_1').hide();
		$('#get_balance').hide();
		$('#get_rpt').show();
	}
})


//添加一个内容
$('.MPhone_table').on('click','.addTMSK',function(){
	var trCount = $('.MPhone_table_body tr').length;
	if(Number(trCount)>10){
		warning.say('最多只能添加10个');
		return;
	}
	
	var html = '';
	var name1 = "mobile"+trCount;
	var name2 = 'content'+trCount;
	var name3 = 'svrtype'+trCount;
	var name4 = 'exnos'+trCount;
	var name5 = 'custid'+trCount;
	var name6 = 'exdata'+trCount;
	html = "<tr><td>"+(trCount)+'</td><td>'+'<input name="'+name1+'"  maxlength = "11" style="float:left;width:120px;margin-left: 0px;" type = "text" /><span style="float:right;" class="required">*</span>'+'</td><td>'+
	'<input name="'+name2+'" style ="width:220px;float:left; margin-left:0px;" type = "text" /><span style="float:right;" class="required">*</span>'+'</td><td>'+
	'<input name="'+name3+'"  style ="width:120px" type = "text" />'+'</td><td>'+
	'<input name="'+name4+'"  style ="width:120px" type = "text" />'+'</td><td>'+
	'<input name="'+name5+'"  style ="width:300px" type = "text" />'+'</td><td>'+
	'<input name="'+name6+'"  style ="width:120px" type = "text" />'+'</td><td><a class="st_deleteSMS">删除</a></td></tr>';
	$('.MPhone_table_body').append(html);
	$("[name='msg_num']").val(trCount);//个性化信息条数
})

//删除一行
$('.MPhone_table').on('click','.st_deleteSMS',function(){
	$(this).closest('tr').remove(); 
	$(".MPhone_table_body tr").each(function(i){
	 	    //获取各个控件
	 	    if(i>0){
	 	    	var ip0 = $(this).children().eq(0);
            ip0.text(i);
            var name1 = "diffMobiles"+i;
	        var name2 = 'diffContents'+i;
	        var name3 = 'diffSvrtypes'+i;
			var name4 = 'diffExnos'+i;
			var name5 = 'diffCustids'+i;
			var name6 = 'diffExdata'+i;
	 	  }
            
   });
})

//提交设置IP信息
$("#setip").click(function () {
	var ip1=$("[name='ip1']").val();
	if(ip1!='')
	{
		var ip1_yz=true;
	}
	if(ip1_yz) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'set_ip'}) + '&' + $('#form_ip').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) //IP设置成功
				{
					$('#first').hide();//设置IP隐藏
					$('#second').show();//业务请求显示
				}
				alert(data['info']);
			},
			error: function (e) {
				alert("ip保存失败");
			}
		});
	}
	else
	{
		alert("请填写主IP信息");
	}
})

//重置清空IP信息
$("#removeip").click(function () {
	$.ajax({
		cache: true,
		type: "POST",
		url:'./DataTransfer.php',
		data:{"Method":'remove_ip'},// ip表单
		dataType: "json",
		success: function(data) {
			if(data['state']==0) //移除成功
			{
				$('#first').show();//设置IP显示
				$('#second').hide();//业务请求隐藏
			}
			else
			{
				$('#first').hide();//设置IP隐藏
				$('#second').show();//业务请求显示
			}
			alert(data['info']);
		},
		error: function(e) {
			$('#first').hide();//设置IP隐藏
			$('#second').show();//业务请求显示
			alert('ip信息重置失败');
		}
	});
})

//模板语音验证码发送
$("#templatesend").click(function () {
	var userid=$("#template_send [name='userid']").val();
	var pwd=$("#template_send [name='pwd']").val();
	var mobile=$("#template_send [name='mobile']").val();
	var content= $("#template_send [name='content']").val();
	var tmplid=$("#template_send [name='tmplid']").val();
	var url=$("#template_send [name='url']").val();
	var exno=$("#template_send [name='exno']").val();
	var custid=$("#template_send [name='custid']").val();
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(mobile!='')
	{
		var yz_mobile=true;
	}
	if(content!='')
	{
		var yz_content=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(tmplid!='')
	{
		var yz_tmplid=true;
	}
	if(exno!='')
	{
		var yz_exno=true;
	}
	if(custid!='')
	{
		var yz_custid=true;
	}
	if(yz_userid&&yz_pwd&&yz_mobile&&yz_content&&yz_url&&yz_tmplid&&yz_exno&&yz_custid) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'template_send'}) + '&' + $('#form_template').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					var str = data['info'] + '  发送号码:' + data['data']['mobile'] + '  梦网流水号:' + data['data']['msgid'] + '  自定义流水号:' + data['data']['custid'];
					$('#template_send textarea.show_result').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					$('#template_send textarea.show_result').html(str);
				}
			},
			error: function (e) {
				$('#template_send textarea.show_result').html("语音验证码发送失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})

//模板语音通知发送
$("#templatesend1").click(function () {
	var userid=$("#template_send_1 [name='userid']").val();
	var pwd=$("#template_send_1 [name='pwd']").val();
	var mobile=$("#template_send_1 [name='mobile']").val();
	var tmplid=$("#template_send_1 [name='tmplid']").val();
	var url=$("#template_send_1 [name='url']").val();
	var exno=$("#template_send_1 [name='exno']").val();
	var custid=$("#template_send_1 [name='custid']").val();
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(mobile!='')
	{
		var yz_mobile=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(tmplid!='')
	{
		var yz_tmplid=true;
	}
	if(exno!='')
	{
		var yz_exno=true;
	}
	if(custid!='')
	{
		var yz_custid=true;
	}
	if(yz_userid&&yz_pwd&&yz_mobile&&yz_url&&yz_tmplid&&yz_exno&&yz_custid) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'template_send_1'}) + '&' + $('#form_template1').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					var str = data['info'] + '  发送号码:' + data['data']['mobile'] + '  梦网流水号:' + data['data']['msgid'] + '  自定义流水号:' + data['data']['custid'];
					$('#template_send_1 textarea.show_result').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					$('#template_send_1 textarea.show_result').html(str);
				}
			},
			error: function (e) {
				$('#template_send_1 textarea.show_result').html("语音通知发送失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})


//查询余额
$("#getbalance").click(function () {
	var userid=$("#get_balance [name='userid']").val();
	var pwd=$("#get_balance [name='pwd']").val();
	var url=$("#get_balance [name='url']").val();
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(yz_userid&&yz_pwd&&yz_url) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'get_balance'}) + '&' + $('#form_balance').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					if (data['data']['chargetype'] == 0) {
						var str = data['info'] + '  计费模式为条数计费，剩余条数为:' + data['data']['balance'] + ' 条';
					}
					else {
						var str = data['info'] + '  计费模式为金额计费，剩余金额为:' + data['data']['money'] + ' 元';
					}
					$('#get_balance textarea.show_result').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					$('#get_balance textarea.show_result').html(str);
				}
			},
			error: function (e) {
				$('#get_balance textarea.show_result').html("查询余额失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})


//获取状态报告
$("#getrpt").click(function () {
	var userid=$("#get_rpt [name='userid']").val();
	var pwd=$("#get_rpt [name='pwd']").val();
	var url=$("#get_rpt [name='url']").val();
	if(userid!='')
	{
		var yz_userid=true;
	}
	if(pwd!='')
	{
		var yz_pwd=true;
	}
	if(url!='')
	{
		var yz_url=true;
	}
	if(yz_userid&&yz_pwd&&yz_url) {
		$.ajax({
			cache: true,
			type: "POST",
			url: './DataTransfer.php',
			data: $.param({"Method": 'get_rpt'}) + '&' + $('#form_rpt').serialize(),// ip表单
			dataType: "json",
			success: function (data) {
				if (data['state'] == 0) {
					if (data['data']['rpts'] == '') {
						alert('暂无状态报告信息');
					}
					else {
						var rpt = '';
						$.each(data['data']['rpts'], function (rpts, v) {   // 遍历Object数组 ，每个对象的值存放在value ，index2表示为第几个对象
							rpt += '<tr><th>' + v.msgid + '</th> <th>' + v.pknum + '</th> <th>' + v.pktotal + '</th> <th>' + v.mobile + '</th> <th>' + v.stime + '</th><th>' + v.status + '</th><th>' + v.errcode + '</th><th>' + v.errdesc + '</th> </tr>'
						});
						var str = '<tr><th>平台流水号</th><th>当前条数</th> <th>总条数</th> <th>手机号</th><th>发送时间</th><th>接收状态</th> <th>错误代码</th> <th>错误代码描述</th><tr>' + rpt;
					}
					$('.st_SMS_Status_body').html(str);
				}
				else {
					var str = data['info'] + '  错误代码:' + data['data']['result'];
					alert(str);
				}
			},
			error: function (e) {
				alert("获取状态报告失败");
			}
		});
	}
	else
	{
		alert("存在必填信息未填写，请将必填信息全部填写");
	}
})