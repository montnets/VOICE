<?php
/**
 * Created by PhpStorm.
 * Date: 2016-11-28
 * Time: 13:54
 * @功能概要：字段加密类
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
class EncryptUtil
{
    /**
     * 密码加密
     * $userid：用户账号
     * $pwd：用户密码
     */
    public function encrypt_pwd($userid, $pwd)
    {
        try {
            $char = '00000000';//固定字符串
            $time = date('mdHis', time());//时间戳
            $pwd = md5($userid . $char . $pwd . $time);//拼接字符串进行加密
            return array('pwd' => $pwd, 'time' => $time);
        } catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }
    /**
     * 语音内容加密
     * $content：语音内容
     */
    public function encrypt_content($content)
    {
        try {
            return urlencode(iconv('UTF-8', 'GBK', $content));//语音内容转化为GBK格式再进行urlencode格式加密
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }
}
?>