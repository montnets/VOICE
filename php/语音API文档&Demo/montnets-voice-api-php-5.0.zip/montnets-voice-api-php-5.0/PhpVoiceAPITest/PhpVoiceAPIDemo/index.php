<?php
/**
 * Created by PhpStorm.
 * Date: 2017-2-28
 * Time: 10:15
 * @功能概要：调用DEMO
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('VoiceSendConn.php');
require_once('ConfigManager.php');

/*
* 设置主备IP信息
*/
/*$ConfigManager=new ConfigManager();
//主IP
$ip['ipAddress1']='192.168.2.6:1000';
//备IP1
$ip['ipAddress2']='192.168.2.6:1001';
//备IP2
$ip['ipAddress3']='192.168.2.6:1002';
//备IP3
$ip['ipAddress4']='192.168.2.6:1003';
try {
    if ($ConfigManager->set_usableip($ip)) {
        print_r("IP设置成功！");
    } else {
        print_r("IP设置失败！");
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/

/*
* 清除所有IP信息
*/
/*$ConfigManager = new ConfigManager();
try {
    if ($ConfigManager->removeAllIpInfo()) {
        print_r("所有IP信息清除成功！");
    } else {
        print_r("所有IP信息清除失败！");
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/

/*
* 模板发送
*/
/*$VoiceSendConn=new VoiceSendConn();
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='yu0006';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
// 设置手机号码 此处只能设置一个手机号码
$data['mobile']='136xxxxxxxx';
//设置发送语音内容
$data['content']='1234';
// 设置回拨号码
$data['exno']='11';
//用户自定义流水编号
$data['custid']='b3d1a2783d31b21b8573';
// 语音模版编号
$data['tmplid']='200170';
// 消息类型
$data['msgtype']='1';
//请求地址
$url='/voice/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $result = $VoiceSendConn->templateSend($url, $data, $isEncryptPwd);
    if ($result['result'] === 0) {
        print_r("模板语音发送成功！");
    } else {
        print_r("模板语音发送失败，错误码：" . $result['result']);
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/


/*
 * 查询剩余金额或条数
 */
/*$VoiceSendConn=new VoiceSendConn();
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='yu0006';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
//请求地址
$url='/voice/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $result = $VoiceSendConn->getBalance($url, $data, $isEncryptPwd);
    if ($result['result'] === 0) {
        if ($result['chargetype'] === 0) {
            print_r("查询成功，当前计费模式为条数计费,剩余条数为：" . $result['balance']);
        } else if ($result['chargetype'] === 1) {
            print_r("查询成功，当前计费模式为金额计费,剩余金额为：" . $result['money']);
        } else {
            print_r("未知的计费类型");
        }
    } else {
        print_r("查询余额失败，错误码：" . $result['result']);
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/


/*
 * 获取状态报告
 */

/*$VoiceSendConn=new VoiceSendConn();
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='yu0006';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
// 设置获取上行的最大条数
$data['retsize']='100';
//请求地址
$url='/voice/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $result = $VoiceSendConn->getRpt($url, $data, $isEncryptPwd);//获取状态报告
    if($result['result']===0)
    {
        print_r("获取状态报告成功");
        print_r($result['rpts']);//输出状态报告信息
    }
    else
    {
        print_r("获取状态报告失败，错误码：" .$result['result']);
    }
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/


/*
 * 线程获取状态报告(由于此处线程已设置为永久执行，一旦启用只能通过重启服务器关闭，不要多次调用该线程方法，否则每次调用都会开启一个新的线程占用资源，请谨慎使用)
 */
/*require_once('RecvRptThread.php');
//初始化数组
$data=array();
//设置账号(账号需要大写)
$data['userid']='yu0006';
//设置密码（密码MD5加密模式下时间戳在encrypt_pwd函数中自动获取时间戳并生成MD5密文密码，在这里不管加密还是不加密都不用设置时间戳）
$data['pwd']='123456';
// 设置获取上行的最大条数
$data['retsize']='100';
//请求地址
$url='/voice/v2/std/';
//密码是否加密
$isEncryptPwd=true;
try {
    $RecvRptThread = new RecvRptThread($url, $data, $isEncryptPwd);
    $RecvRptThread->start();//开始执行线程
}catch (Exception $e) {
    print_r($e->getMessage());//输出捕获的异常消息
    return false;
}*/
?>