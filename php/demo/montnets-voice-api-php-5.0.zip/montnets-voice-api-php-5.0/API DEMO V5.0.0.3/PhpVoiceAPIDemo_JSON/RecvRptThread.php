<?php
/**
 * Created by PhpStorm.
 * Date: 2016-10-13
 * Time: 10:15
 * @功能概要：线程获取状态报告类
 * @公司名称： ShenZhen Montnets Technology CO.,LTD.
 */
require_once('EncryptUtil.php');
require_once('VoiceSendConn.php');
/*
 * 线程获取状态报告
*/
class RecvRptThread extends \Thread
{
    public $url;
    public $data;
    public $isEncryptPwd;
    /*
     * 将传入的请求参数对全局参数进行赋值
     */
    public function __construct($url,$data,$isEncryptPwd)
    {
        $this->url=$url;//获取传入的请求路径
        $this->data=$data;//获取传入的请求数据
        $this->isEncryptPwd=$isEncryptPwd;//获取账号鉴权方式(明文/密文)
    }
    /*
     * 循环执行线程任务
     */
    public function running()
    {
        try {
            $VoiceSendConn=new VoiceSendConn();
            while (true) {
                $url=$this->url;//获取传入的请求地址
                $data=$this->data;//获取传入的请求数据
                $isEncryptPwd=$this->isEncryptPwd;//获取账号鉴权方式(明文/密文)
                $result=$VoiceSendConn->getRpt($url,$data,$isEncryptPwd);//获取状态报告;
                if($result['rpts']==null)
                {
                    /*
                     *此处获取到状态报告后可根据需要写入将状态报告数据录入数据库的代码
                     */
                    sleep(5);//睡眠5秒
                }
            }
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }
    /*
     *执行线程
    */
    public function run()
    {
        try {
            set_time_limit(0);//永久执行该线程任务
            $this->running();//开始线程任务
        }catch (Exception $e) {
            print_r($e->getMessage());  //输出捕获的异常消息
        }
    }
}
?>