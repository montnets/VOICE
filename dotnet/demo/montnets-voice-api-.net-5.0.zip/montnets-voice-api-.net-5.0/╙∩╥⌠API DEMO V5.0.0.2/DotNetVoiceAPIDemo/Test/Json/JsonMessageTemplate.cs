﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;


namespace Test.Json {
    class JsonMessageTemplate {

     
        /// <summary>
        /// 封装报文
        /// </summary>
        /// <param name="sendType">发送请求类型</param>
        /// <param name="message">消息体</param>
        /// <param name="authenticationMode">鉴权方式</param>
        /// <returns></returns>
        public static string getContentString(int sendType, Message message, int authenticationMode) {
            if (sendType == 1)
                return getTemplateContentString(message, authenticationMode); 
            else if (sendType == 5)
                return getRptContentString(message, authenticationMode);
            else if (sendType == 6)
                return getBalanceContentString(message, authenticationMode);

            return null;
        }
        /// <summary>
        /// 获取模板发送封装Json数据 
        /// </summary>
        /// <param name="message">消息体</param>
        /// <param name="authenticationMode">鉴权方式</param>
        /// <returns></returns>
        private static string getTemplateContentString(Message message, int authenticationMode) {
            string contents = null;
            if (authenticationMode == 0) {
                contents = string.Format( TMP_SEND_CONTENT_JSON_NORMAL,
                                     message.UserId,
                                     message.Pwd,
                                     message.Mobile,
                                     HttpUtility.UrlEncode(message.Content, Encoding.GetEncoding("GBK")),
                                      message.TimeStamp,
                      (string.IsNullOrEmpty(message.ExNo) ? string.Empty : message.ExNo),
                      (string.IsNullOrEmpty(message.CustId) ? string.Empty : message.CustId),
                      (string.IsNullOrEmpty(message.Tmplid) ? string.Empty : message.Tmplid),
                                            message.MsgType);

            } else {
                contents = string.Format( TMP_SEND_CONTENT_JSON_APIKEY,
                       message.ApiKey,
                       message.Mobile,
                       HttpUtility.UrlEncode(message.Content, Encoding.GetEncoding("GBK")),
                       message.TimeStamp,
                      (string.IsNullOrEmpty(message.ExNo) ? string.Empty : message.ExNo),
                      (string.IsNullOrEmpty(message.CustId) ? string.Empty : message.CustId),
                      (string.IsNullOrEmpty(message.Tmplid) ? string.Empty : message.Tmplid),
                                            message.MsgType);

                  
            }
            //两端加中括号
            contents = "{" + contents + "}";
            return contents;
        }




        /// <summary>
        /// 获取模板发送封装JSON数据 
        /// </summary>
        /// <param name="message">消息体</param>
        /// <param name="authenticationMode">鉴权方式</param>
        /// <returns></returns>
        private static string getRptContentString(Message message, int authenticationMode) {
            string contents = null;

            if (authenticationMode == 0) {
                contents = string.Format(TMP_RPT_JSON_NORMAL,
                                message.UserId,
                                message.Pwd,
                                message.TimeStamp,
                                message.RetSize);
            } else {
                contents = string.Format(TMP_RPT_JSON_APIKEY,
                      message.ApiKey,
                      message.TimeStamp,
                      message.RetSize);
            }
            //两端加中括号
            contents = "{" + contents + "}";
            return contents;
        }
        /// <summary>
        /// 获取客户剩余金额和剩余条数发送封装JSON数据
        /// </summary>
        /// <param name="message">消息体</param>
        /// <param name="authenticationMode">鉴权方式</param>
        /// <returns></returns>
        private static string getBalanceContentString(Message message, int authenticationMode) {
            string contents = null;
            if (authenticationMode == 0) {
                contents = string.Format(TMP_BALANCE_JSON_NORMAL,
                    message.UserId,
                    message.Pwd,
                    message.TimeStamp);
            } else {
                contents = string.Format(TMP_BALANCE_JSON_APIKEY,
                       message.ApiKey,
                      message.TimeStamp);
            }
            //两端加中括号
            contents = "{" + contents + "}";
            return contents;
        }


        #region 发送报文模板
       
        /// <summary>
        /// 发送报文JSON，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_SEND_CONTENT_JSON_NORMAL = "\"userid\":\"{0}\",\"pwd\":\"{1}\",\"mobile\":\"{2}\",\"content\":\"{3}\",\"timestamp\":\"{4}\",\"exno\":\"{5}\",\"custid\":\"{6}\",\"tmplid\":\"{7}\",\"msgtype\":\"{8}\"";

        /// <summary>
        /// 发送报文JSON， APIKEY鉴权模板 
        /// </summary>
        public const string TMP_SEND_CONTENT_JSON_APIKEY = "\"apikey\":\"{0}\",\"mobile\":\"{1}\",\"content\":\"{2}\",\"timestamp\":\"{3}\",\"exno\":\"{4}\",\"custid\":\"{5}\",\"tmplid\":\"{6}\",\"msgtype\":\"{7}\"";

       

        #endregion
         

        #region 获取RPT报文模板
           /// <summary>
        /// 获取RPT报文JSON，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_RPT_JSON_NORMAL = "\"userid\":\"{0}\",\"pwd\":\"{1}\",\"timestamp\":\"{2}\",\"retsize\":{3}";
        /// <summary>
        /// 获取RPT报文JSON， APIKEY鉴权模板 
        /// </summary>
        public const string TMP_RPT_JSON_APIKEY = "\"apikey\":\"{0}\",\"timestamp\":\"{1}\",\"retsize\":{2}";

        
        #endregion

        #region 获取查询余额报文模板
      
        /// <summary>
        /// 获取查询余额报文JSON，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_BALANCE_JSON_NORMAL = "\"userid\":\"{0}\",\"pwd\":\"{1}\",\"timestamp\":\"{2}\"";
        /// <summary>
        /// 获取查询余额报文JSON， APIKEY鉴权模板 
        /// </summary>
        public const string TMP_BALANCE_JSON_APIKEY = "\"apikey\":\"{0}\",\"timestamp\":\"{1}\"";
 
        #endregion

    }
}
