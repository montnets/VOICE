﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;


namespace Test.XML {
    class XMLMessageTemplate {


        /// <summary>
        /// 封装报文
        /// </summary>
        /// <param name="sendType">发送请求类型</param>
        /// <param name="message">消息体</param>
        /// <param name="authenticationMode">鉴权方式</param>
        /// <returns></returns>
        public static string getContentString(int sendType, Message message, int authenticationMode) {
            if (sendType == 1)
                return getTemplateContentString(message, authenticationMode); 
            else if (sendType == 5)
                return getRptContentString(message, authenticationMode);
            else if (sendType == 6)
                return getBalanceContentString(message, authenticationMode);

            return null;
        }
        /// <summary>
        /// 获取模板发送封装XML数据 
        /// </summary>
        /// <param name="message">消息体</param>
        /// <param name="authenticationMode">鉴权方式</param>
        /// <returns></returns>
        private static string getTemplateContentString(Message message, int authenticationMode) {
            string contents = null;
            if (authenticationMode == 0) {
                contents = string.Format(TMP_SEND_CONTENT_XML_NORMAL,
                           message.UserId,
                           message.Pwd,
                           message.Mobile,
                           HttpUtility.UrlEncode(message.Content, Encoding.GetEncoding("GBK")),
                            message.TimeStamp,
                      (string.IsNullOrEmpty(message.ExNo) ? string.Empty : message.ExNo),
                      (string.IsNullOrEmpty(message.CustId) ? string.Empty : message.CustId),
                      (string.IsNullOrEmpty(message.Tmplid) ? string.Empty : message.Tmplid),
                      message.MsgType);
            } else {
                contents = string.Format(  TMP_SEND_CONTENT_XML_APIKEY,
                      message.ApiKey,
                      message.Mobile,
                      HttpUtility.UrlEncode(message.Content, Encoding.GetEncoding("GBK")),
                      message.TimeStamp,
                      (string.IsNullOrEmpty(message.ExNo) ? string.Empty : message.ExNo),
                      (string.IsNullOrEmpty(message.CustId) ? string.Empty : message.CustId),
                      (string.IsNullOrEmpty(message.Tmplid) ? string.Empty : message.Tmplid),
                                            message.MsgType);

                 
                
            }
            return contents;
        }
        
        /// <summary>
        /// 获取状态报告封装XML数据 
        /// </summary>
        /// <param name="message">消息体</param>
        /// <param name="authenticationMode">鉴权方式</param>
        /// <returns></returns>
        private static string getRptContentString(Message message, int authenticationMode) {
            string contents = null;

            if (authenticationMode == 0) {
                contents = string.Format(TMP_RPT_XML_NORMAL,
                                     message.UserId,
                                     message.Pwd,
                                     message.TimeStamp,
                                     message.RetSize);
            } else {
                contents = string.Format( TMP_RPT_XML_APIKEY,
                       message.ApiKey,
                        message.TimeStamp,
                        message.RetSize);
            }

            return contents;
        }

        /// <summary>
        /// 获取客户剩余金额和剩余条数发送封装XML数据
        /// </summary>
        /// <param name="message">消息体</param>
        /// <param name="authenticationMode">鉴权方式</param>
        /// <returns></returns>
        private static string getBalanceContentString(Message message, int authenticationMode) {
            string contents = null;
            if (authenticationMode == 0) {
                contents = string.Format(TMP_BALANCE_XML_NORMAL,
                     message.UserId,
                     message.Pwd,
                     message.TimeStamp);
            } else {
                contents = string.Format(TMP_BALANCE_XML_APIKEY,
                       message.ApiKey,
                       message.TimeStamp);
            }

            return contents;
        }


        #region 发送报文模板
       
        /// <summary>
        /// 发送报文XML，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_SEND_CONTENT_XML_NORMAL = "<?xml version=\"1.0\" encoding=\"utf-8\"?><mtreq><userid>{0}</userid><pwd>{1}</pwd><mobile>{2}</mobile><content>{3}</content><timestamp>{4}</timestamp><exno>{5}</exno><custid>{6}</custid><tmplid>{7}</tmplid><msgtype>{8}</msgtype></mtreq>";

        /// <summary>
        /// 发送报文XML， APIKEY鉴权模板 
        /// </summary>
        public const string TMP_SEND_CONTENT_XML_APIKEY = "<?xml version=\"1.0\" encoding=\"utf-8\"?><mtreq><apikey>{0}</userid><mobile>{1}</mobile><content>{2}</content><timestamp>{3}</timestamp><exno>{4}</svrtype><custid>{5}</custid><tmplid>{6}</tmplid><msgtype>{7}</msgtype></mtreq>";


        #endregion
         
         

        #region 获取RPT报文模板
      
        /// <summary>
        /// 获取RPT报文XML，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_RPT_XML_NORMAL = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><rptreq>	<userid>{0}</userid><pwd>{1}</pwd><timestamp>{2}</timestamp><retsize>{3}</retsize></rptreq>";

        /// <summary>
        /// 获取RPT报文XML，APIKEY鉴权模板 
        /// </summary>
        public const string TMP_RPT_XML_APIKEY = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><rptreq>	<apikey>{0}</apikey> <timestamp>{1}</timestamp><retsize>{2}</retsize></rptreq>";

        #endregion

        #region 获取查询余额报文模板
      
        /// <summary>
        /// 获取查询余额报文XML，默认账号+密码鉴权模板 
        /// </summary>
        public const string TMP_BALANCE_XML_NORMAL = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><feereq>	<userid>{0}</userid><pwd>{1}</pwd><timestamp>{2}</timestamp></feereq>";

        /// <summary>
        /// 获取查询余额报文XML，APIKEY鉴权模板 
        /// </summary>
        public const string TMP_BALANCE_XML_APIKEY = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><feereq>	<apikey>{0}</apikey> <timestamp>{1}</timestamp></feereq>";

        #endregion

    }
}
