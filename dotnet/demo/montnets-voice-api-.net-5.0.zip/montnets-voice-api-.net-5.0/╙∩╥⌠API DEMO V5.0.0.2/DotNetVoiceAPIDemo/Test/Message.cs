﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test {
    public class Message {

        /// <summary>
        /// 获取或设置用户账号
        /// </summary>
        public String UserId { get; set; }

        /// <summary>
        ///   获取或设置用户密码
        /// </summary>
        public String Pwd { get; set; }

        /// <summary>
        /// 
        ///  获取或设置目标号码，用英文逗号(,)分隔，最大1000个号码。一次提交的号码类型不受限制，但手机会做验证，若有不合法的手机号将会被退回。号码段类型分为：移动、联通、电信手机
        /// 注意：请不要使用中文的逗号
        /// </summary>
        public String Mobile { get; set; }

        /// <summary>
        ///   获取或设置短信内容， 内容长度不大于990个汉字
        /// </summary>
        public String Content { get; set; }

        /// <summary>
        ///  获取或设置时间戳
        /// 时间戳,格式为:MMDDHHMMSS,即月日时分秒,定长10位,月日时分秒不足2位时左补0.时间戳请获取您真实的服务器时间,不要填写固定的时间,否则pwd参数起不到加密作用
        /// 
        /// </summary>
        public String TimeStamp { get; set; }

        /// <summary>
        ///   获取或设置业务类型 最大可支持32位的字符串。预留字段，暂不生效。
        /// </summary>
        public int MsgType { get; set; }

        /// <summary>
        /// 
        ///  获取或设置子端口号码，不带请填星号{*}
        /// 长度由账号类型定4-6位，通道号总长度不能超过20位。如：10657****主通道号，3321绑定的扩展端口，主+扩展+子端口总长度不能超过20位。
        /// </summary>
        public String ExNo { get; set; }

        /// <summary>
        ///   获取或设置该条短信在您业务系统内的ID，比如订单号或者短信发送记录的流水号。填写后发送状态返回值内将包含这个ID.最大可支持64位的字符串
        /// </summary>
        public String CustId { get; set; }

        /// <summary>
        /// 语音模版编号	消息类型为1,2时可填空字符串，消息类型为3时不可填空字符串，必须填语音模板编号
        /// </summary>
        public String Tmplid { get; set; }

        /// <summary>
        /// 本次请求想要获取的上行最大条数。最大500，超过500按500返回。小于等于0或不填时，系统返回默认条数，默认500条
        /// </summary>
        public int RetSize { get; set; }

        /// <summary>
        /// APIKEY
        /// </summary>
        public string ApiKey { get; set; }



    }
}
