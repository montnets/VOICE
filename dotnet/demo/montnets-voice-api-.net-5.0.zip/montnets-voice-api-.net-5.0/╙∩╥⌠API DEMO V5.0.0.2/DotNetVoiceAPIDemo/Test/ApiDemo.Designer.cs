﻿namespace Test {
    partial class ApiDemo {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ApiDemo));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rb_aut_userid_pwd = new System.Windows.Forms.RadioButton();
            this.rb_auth_apikey = new System.Windows.Forms.RadioButton();
            this.rb_aut_userid = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rb_XML = new System.Windows.Forms.RadioButton();
            this.rb_Json = new System.Windows.Forms.RadioButton();
            this.rb_UrlEncode = new System.Windows.Forms.RadioButton();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.rd_no = new System.Windows.Forms.RadioButton();
            this.rd_yes = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.account_setting = new System.Windows.Forms.GroupBox();
            this.btn_ok = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_apikey = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_m_ipport = new System.Windows.Forms.TextBox();
            this.txt_pwd = new System.Windows.Forms.TextBox();
            this.txt_userid = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabPG = new System.Windows.Forms.TabControl();
            this.tab_1 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btn_template_send = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_tmplid = new System.Windows.Forms.TextBox();
            this.txt_custid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_exno = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_mobile = new System.Windows.Forms.TextBox();
            this.txt_message = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txt_result_single = new System.Windows.Forms.TextBox();
            this.tab_5 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.btn_rpt_thread = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.txt_rpt_retsize = new System.Windows.Forms.TextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.txt_result_rpt = new System.Windows.Forms.TextBox();
            this.tab_6 = new System.Windows.Forms.TabPage();
            this.txt_balance = new System.Windows.Forms.TextBox();
            this.btn_getBalance = new System.Windows.Forms.Button();
            this.cb_msgtype = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_b_ipport3 = new System.Windows.Forms.TextBox();
            this.txt_b_ipport2 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_b_ipport1 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.account_setting.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPG.SuspendLayout();
            this.tab_1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tab_5.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tab_6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.account_setting);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1175, 182);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基本设置";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel2);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.rd_no);
            this.groupBox2.Controls.Add(this.rd_yes);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(669, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(503, 162);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "其他设置";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rb_aut_userid_pwd);
            this.panel2.Controls.Add(this.rb_auth_apikey);
            this.panel2.Controls.Add(this.rb_aut_userid);
            this.panel2.Location = new System.Drawing.Point(123, 90);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(356, 27);
            this.panel2.TabIndex = 14;
            // 
            // rb_aut_userid_pwd
            // 
            this.rb_aut_userid_pwd.AutoSize = true;
            this.rb_aut_userid_pwd.Location = new System.Drawing.Point(141, 5);
            this.rb_aut_userid_pwd.Name = "rb_aut_userid_pwd";
            this.rb_aut_userid_pwd.Size = new System.Drawing.Size(77, 16);
            this.rb_aut_userid_pwd.TabIndex = 15;
            this.rb_aut_userid_pwd.Text = "账号+密码";
            this.rb_aut_userid_pwd.UseVisualStyleBackColor = true;
            this.rb_aut_userid_pwd.CheckedChanged += new System.EventHandler(this.rb_aut_userid_pwd_CheckedChanged);
            // 
            // rb_auth_apikey
            // 
            this.rb_auth_apikey.AutoSize = true;
            this.rb_auth_apikey.Location = new System.Drawing.Point(281, 6);
            this.rb_auth_apikey.Name = "rb_auth_apikey";
            this.rb_auth_apikey.Size = new System.Drawing.Size(59, 16);
            this.rb_auth_apikey.TabIndex = 14;
            this.rb_auth_apikey.Text = "ApiKey";
            this.rb_auth_apikey.UseVisualStyleBackColor = true;
            this.rb_auth_apikey.CheckedChanged += new System.EventHandler(this.rb_auth_apikey_CheckedChanged);
            // 
            // rb_aut_userid
            // 
            this.rb_aut_userid.AutoSize = true;
            this.rb_aut_userid.Checked = true;
            this.rb_aut_userid.Location = new System.Drawing.Point(4, 5);
            this.rb_aut_userid.Name = "rb_aut_userid";
            this.rb_aut_userid.Size = new System.Drawing.Size(107, 16);
            this.rb_aut_userid.TabIndex = 13;
            this.rb_aut_userid.TabStop = true;
            this.rb_aut_userid.Text = "MD5(账号+密码)";
            this.rb_aut_userid.UseVisualStyleBackColor = true;
            this.rb_aut_userid.CheckedChanged += new System.EventHandler(this.rb_aut_userid_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rb_XML);
            this.panel1.Controls.Add(this.rb_Json);
            this.panel1.Controls.Add(this.rb_UrlEncode);
            this.panel1.Location = new System.Drawing.Point(122, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 28);
            this.panel1.TabIndex = 13;
            // 
            // rb_XML
            // 
            this.rb_XML.AutoSize = true;
            this.rb_XML.Location = new System.Drawing.Point(153, 7);
            this.rb_XML.Name = "rb_XML";
            this.rb_XML.Size = new System.Drawing.Size(41, 16);
            this.rb_XML.TabIndex = 12;
            this.rb_XML.Text = "XML";
            this.rb_XML.UseVisualStyleBackColor = true;
            this.rb_XML.CheckedChanged += new System.EventHandler(this.rb_XML_CheckedChanged);
            // 
            // rb_Json
            // 
            this.rb_Json.AutoSize = true;
            this.rb_Json.Location = new System.Drawing.Point(89, 6);
            this.rb_Json.Name = "rb_Json";
            this.rb_Json.Size = new System.Drawing.Size(47, 16);
            this.rb_Json.TabIndex = 11;
            this.rb_Json.Text = "Json";
            this.rb_Json.UseVisualStyleBackColor = true;
            this.rb_Json.CheckedChanged += new System.EventHandler(this.rb_Json_CheckedChanged);
            // 
            // rb_UrlEncode
            // 
            this.rb_UrlEncode.AutoSize = true;
            this.rb_UrlEncode.Checked = true;
            this.rb_UrlEncode.Location = new System.Drawing.Point(4, 7);
            this.rb_UrlEncode.Name = "rb_UrlEncode";
            this.rb_UrlEncode.Size = new System.Drawing.Size(77, 16);
            this.rb_UrlEncode.TabIndex = 10;
            this.rb_UrlEncode.TabStop = true;
            this.rb_UrlEncode.Text = "UrlEncode";
            this.rb_UrlEncode.UseVisualStyleBackColor = true;
            this.rb_UrlEncode.CheckedChanged += new System.EventHandler(this.rb_UrlEncode_CheckedChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(42, 96);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 12);
            this.label40.TabIndex = 10;
            this.label40.Text = "鉴权方式：";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(42, 55);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(65, 12);
            this.label39.TabIndex = 6;
            this.label39.Text = "报文类型：";
            // 
            // rd_no
            // 
            this.rd_no.AutoSize = true;
            this.rd_no.Location = new System.Drawing.Point(184, 23);
            this.rd_no.Name = "rd_no";
            this.rd_no.Size = new System.Drawing.Size(35, 16);
            this.rd_no.TabIndex = 4;
            this.rd_no.Text = "否";
            this.rd_no.UseVisualStyleBackColor = true;
            this.rd_no.CheckedChanged += new System.EventHandler(this.rd_no_CheckedChanged);
            // 
            // rd_yes
            // 
            this.rd_yes.AutoSize = true;
            this.rd_yes.Checked = true;
            this.rd_yes.Location = new System.Drawing.Point(127, 22);
            this.rd_yes.Name = "rd_yes";
            this.rd_yes.Size = new System.Drawing.Size(35, 16);
            this.rd_yes.TabIndex = 3;
            this.rd_yes.TabStop = true;
            this.rd_yes.Text = "是";
            this.rd_yes.UseVisualStyleBackColor = true;
            this.rd_yes.CheckedChanged += new System.EventHandler(this.rd_yes_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "是否长连接：";
            // 
            // account_setting
            // 
            this.account_setting.Controls.Add(this.label6);
            this.account_setting.Controls.Add(this.label5);
            this.account_setting.Controls.Add(this.txt_b_ipport3);
            this.account_setting.Controls.Add(this.txt_b_ipport2);
            this.account_setting.Controls.Add(this.label13);
            this.account_setting.Controls.Add(this.txt_b_ipport1);
            this.account_setting.Controls.Add(this.btn_ok);
            this.account_setting.Controls.Add(this.label41);
            this.account_setting.Controls.Add(this.label3);
            this.account_setting.Controls.Add(this.label2);
            this.account_setting.Controls.Add(this.txt_apikey);
            this.account_setting.Controls.Add(this.label1);
            this.account_setting.Controls.Add(this.txt_m_ipport);
            this.account_setting.Controls.Add(this.txt_pwd);
            this.account_setting.Controls.Add(this.txt_userid);
            this.account_setting.Dock = System.Windows.Forms.DockStyle.Left;
            this.account_setting.Location = new System.Drawing.Point(3, 17);
            this.account_setting.Name = "account_setting";
            this.account_setting.Size = new System.Drawing.Size(666, 162);
            this.account_setting.TabIndex = 1;
            this.account_setting.TabStop = false;
            this.account_setting.Text = "账号设置";
            // 
            // btn_ok
            // 
            this.btn_ok.Location = new System.Drawing.Point(193, 133);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(75, 23);
            this.btn_ok.TabIndex = 8;
            this.btn_ok.Text = "确 定";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(24, 104);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(53, 12);
            this.label41.TabIndex = 1;
            this.label41.Text = "ApiKey：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "IP/PORT：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "密码：";
            // 
            // txt_apikey
            // 
            this.txt_apikey.Location = new System.Drawing.Point(95, 101);
            this.txt_apikey.Name = "txt_apikey";
            this.txt_apikey.Size = new System.Drawing.Size(212, 21);
            this.txt_apikey.TabIndex = 0;
            this.txt_apikey.Text = "9f76c26fd10c135f01c4e64b2042bef4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "账号：";
            // 
            // txt_m_ipport
            // 
            this.txt_m_ipport.Location = new System.Drawing.Point(94, 71);
            this.txt_m_ipport.Name = "txt_m_ipport";
            this.txt_m_ipport.Size = new System.Drawing.Size(213, 21);
            this.txt_m_ipport.TabIndex = 0;
            this.txt_m_ipport.Text = "192.169.1.234:8080";
            // 
            // txt_pwd
            // 
            this.txt_pwd.Location = new System.Drawing.Point(94, 44);
            this.txt_pwd.Name = "txt_pwd";
            this.txt_pwd.Size = new System.Drawing.Size(213, 21);
            this.txt_pwd.TabIndex = 0;
            this.txt_pwd.Text = "123456";
            // 
            // txt_userid
            // 
            this.txt_userid.Location = new System.Drawing.Point(94, 17);
            this.txt_userid.Name = "txt_userid";
            this.txt_userid.Size = new System.Drawing.Size(213, 21);
            this.txt_userid.TabIndex = 0;
            this.txt_userid.Text = "yu0006";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tabPG);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 182);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1175, 536);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "6个接口";
            // 
            // tabPG
            // 
            this.tabPG.Controls.Add(this.tab_1);
            this.tabPG.Controls.Add(this.tab_5);
            this.tabPG.Controls.Add(this.tab_6);
            this.tabPG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabPG.Location = new System.Drawing.Point(3, 17);
            this.tabPG.Name = "tabPG";
            this.tabPG.SelectedIndex = 0;
            this.tabPG.Size = new System.Drawing.Size(1169, 516);
            this.tabPG.TabIndex = 0;
            // 
            // tab_1
            // 
            this.tab_1.Controls.Add(this.groupBox5);
            this.tab_1.Controls.Add(this.groupBox4);
            this.tab_1.Location = new System.Drawing.Point(4, 22);
            this.tab_1.Name = "tab_1";
            this.tab_1.Padding = new System.Windows.Forms.Padding(3);
            this.tab_1.Size = new System.Drawing.Size(1161, 490);
            this.tab_1.TabIndex = 0;
            this.tab_1.Text = "语音模板发送";
            this.tab_1.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.cb_msgtype);
            this.groupBox5.Controls.Add(this.btn_template_send);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.txt_tmplid);
            this.groupBox5.Controls.Add(this.txt_custid);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.txt_exno);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.txt_mobile);
            this.groupBox5.Controls.Add(this.txt_message);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(3, 233);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1155, 254);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "发送";
            // 
            // btn_template_send
            // 
            this.btn_template_send.Location = new System.Drawing.Point(305, 221);
            this.btn_template_send.Name = "btn_template_send";
            this.btn_template_send.Size = new System.Drawing.Size(75, 23);
            this.btn_template_send.TabIndex = 7;
            this.btn_template_send.Text = "发 送";
            this.btn_template_send.UseVisualStyleBackColor = true;
            this.btn_template_send.Click += new System.EventHandler(this.btn_single_send_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "用户自定义流水编号(CustId)：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 12);
            this.label8.TabIndex = 6;
            this.label8.Text = "消息类型(msgtype)：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 160);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(113, 12);
            this.label11.TabIndex = 6;
            this.label11.Text = "模板ID（tmplid）：";
            // 
            // txt_tmplid
            // 
            this.txt_tmplid.Location = new System.Drawing.Point(186, 155);
            this.txt_tmplid.MaxLength = 64;
            this.txt_tmplid.Name = "txt_tmplid";
            this.txt_tmplid.Size = new System.Drawing.Size(718, 21);
            this.txt_tmplid.TabIndex = 5;
            this.txt_tmplid.Text = "200170";
            // 
            // txt_custid
            // 
            this.txt_custid.Location = new System.Drawing.Point(186, 124);
            this.txt_custid.MaxLength = 64;
            this.txt_custid.Name = "txt_custid";
            this.txt_custid.Size = new System.Drawing.Size(718, 21);
            this.txt_custid.TabIndex = 5;
            this.txt_custid.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(125, 12);
            this.label10.TabIndex = 4;
            this.label10.Text = "回拨显示号码(ExNo)：";
            // 
            // txt_exno
            // 
            this.txt_exno.Location = new System.Drawing.Point(186, 86);
            this.txt_exno.Name = "txt_exno";
            this.txt_exno.Size = new System.Drawing.Size(718, 21);
            this.txt_exno.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(113, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "手机号码(Mobile)：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 12);
            this.label9.TabIndex = 2;
            this.label9.Text = "内容(Message)：";
            // 
            // txt_mobile
            // 
            this.txt_mobile.Location = new System.Drawing.Point(186, 56);
            this.txt_mobile.Name = "txt_mobile";
            this.txt_mobile.Size = new System.Drawing.Size(718, 21);
            this.txt_mobile.TabIndex = 0;
            this.txt_mobile.Text = "15989321542";
            // 
            // txt_message
            // 
            this.txt_message.Location = new System.Drawing.Point(186, 26);
            this.txt_message.Name = "txt_message";
            this.txt_message.Size = new System.Drawing.Size(718, 21);
            this.txt_message.TabIndex = 0;
            this.txt_message.Text = "666666";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txt_result_single);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1155, 230);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "单条发送返回报文";
            // 
            // txt_result_single
            // 
            this.txt_result_single.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_result_single.Location = new System.Drawing.Point(3, 17);
            this.txt_result_single.Multiline = true;
            this.txt_result_single.Name = "txt_result_single";
            this.txt_result_single.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_result_single.Size = new System.Drawing.Size(1149, 210);
            this.txt_result_single.TabIndex = 0;
            // 
            // tab_5
            // 
            this.tab_5.Controls.Add(this.groupBox12);
            this.tab_5.Controls.Add(this.groupBox13);
            this.tab_5.Location = new System.Drawing.Point(4, 22);
            this.tab_5.Name = "tab_5";
            this.tab_5.Size = new System.Drawing.Size(934, 490);
            this.tab_5.TabIndex = 4;
            this.tab_5.Text = "接收状态报告";
            this.tab_5.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button4);
            this.groupBox12.Controls.Add(this.btn_rpt_thread);
            this.groupBox12.Controls.Add(this.button6);
            this.groupBox12.Controls.Add(this.label30);
            this.groupBox12.Controls.Add(this.txt_rpt_retsize);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox12.Location = new System.Drawing.Point(0, 368);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(934, 122);
            this.groupBox12.TabIndex = 10;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "发送";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(587, 36);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 8;
            this.button4.Text = "停止线程";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_rpt_thread
            // 
            this.btn_rpt_thread.Location = new System.Drawing.Point(481, 34);
            this.btn_rpt_thread.Name = "btn_rpt_thread";
            this.btn_rpt_thread.Size = new System.Drawing.Size(75, 23);
            this.btn_rpt_thread.TabIndex = 9;
            this.btn_rpt_thread.Text = "线程接收";
            this.btn_rpt_thread.UseVisualStyleBackColor = true;
            this.btn_rpt_thread.Click += new System.EventHandler(this.btn_rpt_thread_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(388, 31);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 7;
            this.button6.Text = "获 取";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(20, 36);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(119, 12);
            this.label30.TabIndex = 2;
            this.label30.Text = "单次接收(retsize)：";
            // 
            // txt_rpt_retsize
            // 
            this.txt_rpt_retsize.Location = new System.Drawing.Point(139, 33);
            this.txt_rpt_retsize.Name = "txt_rpt_retsize";
            this.txt_rpt_retsize.Size = new System.Drawing.Size(149, 21);
            this.txt_rpt_retsize.TabIndex = 0;
            this.txt_rpt_retsize.Text = "30";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.txt_result_rpt);
            this.groupBox13.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox13.Location = new System.Drawing.Point(0, 0);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(934, 368);
            this.groupBox13.TabIndex = 9;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "接收状态报告报文";
            // 
            // txt_result_rpt
            // 
            this.txt_result_rpt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_result_rpt.Location = new System.Drawing.Point(3, 17);
            this.txt_result_rpt.Multiline = true;
            this.txt_result_rpt.Name = "txt_result_rpt";
            this.txt_result_rpt.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_result_rpt.Size = new System.Drawing.Size(928, 348);
            this.txt_result_rpt.TabIndex = 2;
            // 
            // tab_6
            // 
            this.tab_6.Controls.Add(this.txt_balance);
            this.tab_6.Controls.Add(this.btn_getBalance);
            this.tab_6.Location = new System.Drawing.Point(4, 22);
            this.tab_6.Name = "tab_6";
            this.tab_6.Size = new System.Drawing.Size(934, 490);
            this.tab_6.TabIndex = 5;
            this.tab_6.Text = "获取剩余金额和剩下条数";
            this.tab_6.UseVisualStyleBackColor = true;
            // 
            // txt_balance
            // 
            this.txt_balance.Location = new System.Drawing.Point(193, 163);
            this.txt_balance.Multiline = true;
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.ReadOnly = true;
            this.txt_balance.Size = new System.Drawing.Size(340, 154);
            this.txt_balance.TabIndex = 1;
            // 
            // btn_getBalance
            // 
            this.btn_getBalance.Location = new System.Drawing.Point(286, 115);
            this.btn_getBalance.Name = "btn_getBalance";
            this.btn_getBalance.Size = new System.Drawing.Size(75, 23);
            this.btn_getBalance.TabIndex = 0;
            this.btn_getBalance.Text = "查询余额";
            this.btn_getBalance.UseVisualStyleBackColor = true;
            this.btn_getBalance.Click += new System.EventHandler(this.btn_getBalance_Click);
            // 
            // cb_msgtype
            // 
            this.cb_msgtype.FormattingEnabled = true;
            this.cb_msgtype.Items.AddRange(new object[] {
            "1：语言验证码 ",
            "3：语音通知（语音id）"});
            this.cb_msgtype.Location = new System.Drawing.Point(186, 181);
            this.cb_msgtype.Name = "cb_msgtype";
            this.cb_msgtype.Size = new System.Drawing.Size(121, 20);
            this.cb_msgtype.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(325, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 19;
            this.label6.Text = "备3IP/端口：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(325, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 20;
            this.label5.Text = "备2IP/端口：";
            // 
            // txt_b_ipport3
            // 
            this.txt_b_ipport3.Location = new System.Drawing.Point(408, 76);
            this.txt_b_ipport3.Name = "txt_b_ipport3";
            this.txt_b_ipport3.Size = new System.Drawing.Size(175, 21);
            this.txt_b_ipport3.TabIndex = 17;
            // 
            // txt_b_ipport2
            // 
            this.txt_b_ipport2.Location = new System.Drawing.Point(408, 49);
            this.txt_b_ipport2.Name = "txt_b_ipport2";
            this.txt_b_ipport2.Size = new System.Drawing.Size(175, 21);
            this.txt_b_ipport2.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(325, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 12);
            this.label13.TabIndex = 16;
            this.label13.Text = "备1IP/端口：";
            // 
            // txt_b_ipport1
            // 
            this.txt_b_ipport1.Location = new System.Drawing.Point(408, 23);
            this.txt_b_ipport1.Name = "txt_b_ipport1";
            this.txt_b_ipport1.Size = new System.Drawing.Size(175, 21);
            this.txt_b_ipport1.TabIndex = 15;
            // 
            // ApiDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1175, 718);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ApiDemo";
            this.Text = "语音API 5.0 DEMO ";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.account_setting.ResumeLayout(false);
            this.account_setting.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tabPG.ResumeLayout(false);
            this.tab_1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tab_5.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tab_6.ResumeLayout(false);
            this.tab_6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox account_setting;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_userid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_m_ipport;
        private System.Windows.Forms.TextBox txt_pwd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rd_yes;
        private System.Windows.Forms.RadioButton rd_no;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txt_apikey;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rb_auth_apikey;
        private System.Windows.Forms.RadioButton rb_aut_userid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rb_XML;
        private System.Windows.Forms.RadioButton rb_Json;
        private System.Windows.Forms.RadioButton rb_UrlEncode;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.RadioButton rb_aut_userid_pwd;
        private System.Windows.Forms.TabControl tabPG;
        private System.Windows.Forms.TabPage tab_1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btn_template_send;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_tmplid;
        private System.Windows.Forms.TextBox txt_custid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_exno;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_mobile;
        private System.Windows.Forms.TextBox txt_message;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txt_result_single;
        private System.Windows.Forms.TabPage tab_5;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btn_rpt_thread;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txt_rpt_retsize;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox txt_result_rpt;
        private System.Windows.Forms.TabPage tab_6;
        private System.Windows.Forms.TextBox txt_balance;
        private System.Windows.Forms.Button btn_getBalance;
        private System.Windows.Forms.ComboBox cb_msgtype;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_b_ipport3;
        private System.Windows.Forms.TextBox txt_b_ipport2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_b_ipport1;

    }
}

