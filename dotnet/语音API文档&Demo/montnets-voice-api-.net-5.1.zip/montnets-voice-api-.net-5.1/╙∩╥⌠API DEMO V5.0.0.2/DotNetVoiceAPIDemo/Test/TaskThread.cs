﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Test {
    public  class TaskThread {
        /// <summary>
        /// 已注册线程句柄
        /// </summary>
        public RegisteredWaitHandle Handle = null;
        /// <summary>
        /// 线程描述
        /// </summary>
        public string Description;

        public bool isKeepAlive;
         
        public Message message;

        public int messageType = 0;

        public int authenticationMode = 0;

        public string ipport;

    }
}
