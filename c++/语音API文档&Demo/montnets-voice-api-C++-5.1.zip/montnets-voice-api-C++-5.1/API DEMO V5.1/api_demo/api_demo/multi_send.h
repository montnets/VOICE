#ifndef MULTI_SEND_H
#define MULTI_SEND_H

#include "HttpClient.h"

int multi_send(HttpClient &httpClient, std::string userid, std::string pwd, std::string mobile1, std::string mobile2, std::string content);
std::string URLEncodeDirect(const char *pInBuf);

#endif