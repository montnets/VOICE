#ifndef TEMPLATE_SEND_H
#define TEMPLATE_SEND_H

#include "HttpClient.h"

int template_send(HttpClient &httpClient, std::string userid, std::string pwd, std::string mobile, std::string content);
std::string URLEncodeDirect(const char *pInBuf);

#endif