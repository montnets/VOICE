#ifndef GET_RPT_H
#define GET_RPT_H

#include "HttpClient.h"

int get_rpt(HttpClient &httpClient, std::string userid, std::string pwd);
std::string URLEncodeDirect(const char *pInBuf);

#endif