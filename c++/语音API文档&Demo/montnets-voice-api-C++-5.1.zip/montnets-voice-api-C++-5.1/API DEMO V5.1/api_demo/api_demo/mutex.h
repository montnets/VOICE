#ifndef MUTEX_H
#define MUTEX_H

#ifdef WIN32
#include "win_mutex.h"
#elif defined LINUX
#include "posix_mutex.h"
#else
#error only windows, posix are supported!
#endif

#ifdef WIN32
typedef win_mutex mutex;
#elif defined LINUX
typedef posix_mutex mutex;
#endif

#endif