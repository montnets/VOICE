
#include "batch_send.h"
#include <json/json.h>
#include <stdio.h>
#include "md5.h"
#include <algorithm>
#include "tinyxml/tinyxml.h"
#include <time.h>

int batch_send(HttpClient &httpClient, std::string userid, std::string pwd, std::string mobile, std::string content)
{
#ifdef JSON
	const char *strHeads[6];
	strHeads[0] = "Host: api01.monyun.cn:7901";
	strHeads[1] = "Accept: */*";
	strHeads[2] = "User-Agent: python-requests/2.13.0";
	strHeads[3] = "Accept-Encoding: gzip, deflate";
	strHeads[4] = "Connection: Close";
	strHeads[5] = "Content-Type: application/json";

	// ȡʱ��
	time_t t = time(0);
	struct tm *p = localtime(&t);
	char timestamp[1024];
	sprintf(timestamp, "%02d%02d%02d%02d%02d", p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	//std::string userid = "E10FXA";
	std::string tmp = userid;
	//std::string pwd = "rIkXe2";
	transform(tmp.begin(), tmp.end(), tmp.begin(), toupper);
	std::string md5 = MD5(tmp + "00000000" + pwd + timestamp).toString();

	Json::Value item;
	item["userid"] = userid;
	item["pwd"] = md5;
	item["mobile"] = mobile;
	item["content"] = URLEncodeDirect(content.c_str());
	item["timestamp"] = timestamp;
	item["svrtype"] = "SMS001";
	item["exno"] = "0006";
	item["custid"] = "b3d0a2783d31b21b8573";
	item["exdata"] = "exdata000002";
	Json::FastWriter writer;
	std::string strBody = writer.write(item);

	std::string strHttpRespBody;
	int nHttpRespCode = 0;
	if (httpClient.postHttpRequest(strHeads, sizeof(strHeads) / sizeof(strHeads[0]), strBody, strHttpRespBody, "batch_send", &nHttpRespCode) == 0)
	{
		printf("RespCode: %d\n", nHttpRespCode);
		printf("RespBdoy: %s\n", strHttpRespBody.c_str());
	}

	return 0;

#elif defined XML
	const char *strHeads[6];
	strHeads[0] = "Host: api01.monyun.cn:7901";
	strHeads[1] = "Accept: */*";
	strHeads[2] = "User-Agent: python-requests/2.13.0";
	strHeads[3] = "Accept-Encoding: gzip, deflate";
	strHeads[4] = "Connection: Close";
	strHeads[5] = "Content-Type: application/xml";

	// ȡʱ��
	time_t t = time(0);
	struct tm *p = localtime(&t);
	char timestamp[1024];
	sprintf(timestamp, "%02d%02d%02d%02d%02d", p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	std::string userid = "E10FXA";
	std::string tmp = userid;
	std::string pwd = "rIkXe2";
	transform(tmp.begin(), tmp.end(), tmp.begin(), toupper);
	std::string md5 = MD5(tmp + "00000000" + pwd + timestamp).toString();

	TiXmlElement *pRootElement = new TiXmlElement("mtreq");

	TiXmlElement *pElement1 = new TiXmlElement("userid");
	TiXmlElement *pElement2 = new TiXmlElement("pwd");
	TiXmlElement *pElement3 = new TiXmlElement("mobile");
	TiXmlElement *pElement4 = new TiXmlElement("content");
	TiXmlElement *pElement5 = new TiXmlElement("timestamp");
	TiXmlElement *pElement6 = new TiXmlElement("svrtype");
	TiXmlElement *pElement7 = new TiXmlElement("exno");
	TiXmlElement *pElement8 = new TiXmlElement("custid");
	TiXmlElement *pElement9 = new TiXmlElement("exdata");
	pRootElement->LinkEndChild(pElement1);
	pRootElement->LinkEndChild(pElement2);
	pRootElement->LinkEndChild(pElement3);
	pRootElement->LinkEndChild(pElement4);
	pRootElement->LinkEndChild(pElement5);
	pRootElement->LinkEndChild(pElement6);
	pRootElement->LinkEndChild(pElement7);
	pRootElement->LinkEndChild(pElement8);
	pRootElement->LinkEndChild(pElement9);

	TiXmlText *pText1 = new TiXmlText(userid.c_str());
	pElement1->InsertEndChild(*pText1);

	TiXmlText *pText2 = new TiXmlText(md5.c_str());
	pElement2->InsertEndChild(*pText2);

	TiXmlText *pText3 = new TiXmlText("13169924946,13726256729");
	pElement3->InsertEndChild(*pText3);

	TiXmlText *pText4 = new TiXmlText(URLEncodeDirect("��¼��֤�룺hello world����Ǳ��˲���������Դ˶��š�").c_str());
	pElement4->InsertEndChild(*pText4);

	TiXmlText *pText5 = new TiXmlText(timestamp);
	pElement5->InsertEndChild(*pText5);

	TiXmlText *pText6 = new TiXmlText("SMS001");
	pElement6->InsertEndChild(*pText6);

	TiXmlText *pText7 = new TiXmlText("0006");
	pElement7->InsertEndChild(*pText7);

	TiXmlText *pText8 = new TiXmlText("b3d0a2783d31b21b8573");
	pElement8->InsertEndChild(*pText8);

	TiXmlText *pText9 = new TiXmlText("exdata000002");
	pElement9->InsertEndChild(*pText9);

	TiXmlPrinter printer;
	pRootElement->Accept(&printer);
	std::string strBody = printer.CStr();

	std::string strHttpRespBody;
	int nHttpRespCode = 0;

	return httpClient.postHttpRequest(strHeads, sizeof(strHeads) / sizeof(strHeads[0]), strBody, strHttpRespBody, "batch_send", &nHttpRespCode);

#elif defined URLENCODE
	const char *strHeads[6];
	strHeads[0] = "Host: api01.monyun.cn:7901";
	strHeads[1] = "Accept: */*";
	strHeads[2] = "User-Agent: python-requests/2.13.0";
	strHeads[3] = "Accept-Encoding: gzip, deflate";
	strHeads[4] = "Connection: Close";
	strHeads[5] = "Content-Type: application/x-www-form-urlencoded";

	// ȡʱ��
	time_t t = time(0);
	struct tm *p = localtime(&t);
	char timestamp[1024];
	sprintf(timestamp, "%02d%02d%02d%02d%02d", p->tm_mon + 1, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	std::string userid = "E10FXA";
	std::string tmp = userid;
	std::string pwd = "rIkXe2";
	transform(tmp.begin(), tmp.end(), tmp.begin(), toupper);
	std::string md5 = MD5(tmp + "00000000" + pwd + timestamp).toString();

	std::string strBody = "userid=";
	strBody += userid;
	strBody += "&pwd=";
	strBody += md5;
	strBody += "&mobile=13169924946,13726256729";
	strBody += "&content=";
	strBody += URLEncodeDirect("��¼��֤�룺hello world����Ǳ��˲���������Դ˶��š�");
	strBody += "&timestamp=";
	strBody += timestamp;
	strBody += "&svrtype=SMS001";
	strBody += "&exno=0006";
	strBody += "&custid=b3d0a2783d31b21b8573";
	strBody += "&exdata=exdata000002";

	std::string strHttpRespBody;
	int nHttpRespCode = 0;
	return httpClient.postHttpRequest(strHeads, sizeof(strHeads) / sizeof(strHeads[0]), strBody, strHttpRespBody, "batch_send", &nHttpRespCode);
#else
#error you must define either JSON, XML or URLENCODE!
#endif
}